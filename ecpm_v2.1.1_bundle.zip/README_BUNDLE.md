# ECPM v2.1.1 pre-freeze bundle (2026-08-19)

One archive, three things:

1. `ecpm/` -- the FULL repository including git history. Branch
   `v2.1-prefreeze` is checked out, HEAD `5318c3e`
   (`5318c3e113438c563c5676d58252d84fda22aa49`),
   two commits on top of `eaf49ed`: v2.1 (six review items) and v2.1.1
   (five second-round vetoes). Pushing this tree preserves these exact
   SHAs.
2. `GIST_STATS_CORRECTION.md` -- paste-ready replacement text for the
   Gist doc (sample size, seed-clustered bootstrap, repeat audit
   reported separately, matched-anchor framing for det vs sto).
3. This README.

## Efe: publish the branch

    cd ecpm
    git push -u origin v2.1-prefreeze
    # optional cleanup of the stray patch-as-files commit on main:
    git fetch origin && git checkout -B main origin/main
    git revert --no-edit 598820c && git push origin main
    git checkout v2.1-prefreeze

## Pavlos: rerun everything offline

    cd ecpm
    python3 test_resource_mdp.py        # env battery, 18 tests
    python3 test_ecpm_parser.py         # frozen Section 7 contract
    python3 adversarial_review.py 1000  # your script, v2.1.1-adapted
    python3 ecpm_reply_verification.py  # regression + matched anchors

`adversarial_review.py` carries two noted adaptations: the B=6 call now
records the intended ValueError (0 < B <= k is enforced), and the sweep
seed count is a CLI argument. Expected strict-preservation statuses are
listed in its header.
