# ECPM Phase-2 pilot kit (pinned to 5318c3e)

`run_pilot.py` runs both pilots (matched seed-7 pair, deterministic +
stochastic silent_break) end to end: prompt_view -> prompt -> model ->
frozen parser -> scoring -> one artifact JSON per pilot. Each artifact
retains the agreed list: prompt-safe payload, raw model response, parser
and execution statuses, route/regret, seeds/model settings, realized
event/token counts, and the freeze SHA (with a pinned_to_freeze flag).

## Run

Place run_pilot.py in the repo root, on branch v2.1-prefreeze:

    python3 run_pilot.py                    # dry-run, no API key needed

    ANTHROPIC_API_KEY=...  python3 run_pilot.py \
        --provider anthropic --model claude-sonnet-4-6

    OPENAI_API_KEY=...  python3 run_pilot.py \
        --provider openai --model gpt-4o

Outputs land in pilot_artifacts/. Defaults: temperature 0, rendering
F2_shuffled, budget_per_pair 5, both periods; change via flags.
Preservation queries 4 pairs (the target + 3 unchanged, fixed seed).

## What to send for review

pilot_artifacts/pilot_deterministic.json,
pilot_artifacts/pilot_stochastic.json, and run_pilot.py itself.
sample_artifacts/ holds dry-run outputs (provider "dry-run",
oracle-derived answers) demonstrating the artifact shape and the
green path: detection/localization/preservation ok, adaptation
valid_finite with regret 0.

The harness is intentionally NOT committed to the branch yet, so the
approved tree stays byte-identical to 5318c3e; it joins the repo at
merge time.
